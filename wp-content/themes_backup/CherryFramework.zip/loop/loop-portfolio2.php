<?php /* Loop Name: Portfolio 2 */ ?>
<?php // Theme Options vars
$items_count = of_get_option('items_count2');
$cols = '2cols';

require_once get_template_directory() . '/portfolio-loop.php';